<?php 

return [
    'dsn' => 'mysql:host=localhost;port=3306;dbname=festival;charset=utf8mb4',
    'user' => 'root',
    'pass' => '',
];